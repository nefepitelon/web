import { parse, toDate } from 'date-fns';
import { format, toZonedTime, fromZonedTime } from 'date-fns-tz';
import humanizeDuration from 'humanize-duration';

/** Parse date from string, returns date in UTC! */
export function dateFromString(datestring: string, format: string): Date {
  const localTime = parse(datestring, format, 0);
  return fromZonedTime(localTime, 'UTC');
}

let locTimeZone = 'UTC';

/**
 * Set global timezone to use by conversion functions
 * @param tz Timezone to set
 */
export function setTimezone(tz: string) {
  locTimeZone = tz;
}

function getTimeZone(tz?: string): string {
  return tz || locTimeZone;
}

function formatDate(date: Date, formatPattern: string, timezone?: string): string {
  const timezoneRes = getTimeZone(timezone);
  return format(toZonedTime(date, timezoneRes), formatPattern, {
    timeZone: timezoneRes,
  });
}

/**
 * Convert a timestamp / Date object to String
 * @param ts Timestamp as number or date (in utc!!)
 */
export function timestampms(ts: number | Date): string {
  return formatDate(toDate(ts), 'yyyy-MM-dd HH:mm:ss');
}

/**
 * Convert a timestamp / Date object to String.
 * Returns 'N/A' if ts is null
 * @param ts Timestamp as number or date (in utc!!)
 */
export function timestampmsOrNa(ts: number | Date | null): string {
  return ts ? formatDate(toDate(ts), 'yyyy-MM-dd HH:mm:ss') : 'N/A';
}

/**
 * Convert a timestamp / Date object to String
 * @param ts Timestamp as number or date (in utc!!)
 * @param timezone timezone to use
 * @returns formatted date in desired timezone (or globally configured timezone)
 */
export function timestampmsWithTimezone(ts: number | Date | null, timezone?: string): string {
  if (!ts) {
    return 'N/A';
  }
  return formatDate(toDate(ts), 'yyyy-MM-dd HH:mm:ss (z)', timezone);
}

/**
 * Converts timestamp or Date object to yyyy-MM-dd format.
 * @param ts
 */
export function timestampToDateString(ts: number | Date): string {
  return formatDate(toDate(ts), 'yyyy-MM-dd');
}

/**
 * Converts timestamp or Date object to yyyyMMdd format.
 * Used for timerange displays
 * @param ts
 */
export function timestampToTimeRangeString(ts: number | Date): string {
  const date = toDate(ts);
  const isDay = formatDate(date, 'HH:mm:ss') === '00:00:00';
  if (isDay) {
    return formatDate(date, 'yyyyMMdd');
  }
  const hasSeconds = formatDate(date, 'ss') !== '00';
  return formatDate(date, hasSeconds ? "yyyyMMdd'T'HHmmss" : "yyyyMMdd'T'HHmm");
}

export function timestampHour(ts: number): number {
  return Number(formatDate(toDate(ts), 'HH'));
}

/**
 *  Get humanized Duration from seconds
 * @param duration Duration in seconds
 */
export function humanizeDurationFromSeconds(duration: number | undefined): string {
  return duration ? humanizeDuration(duration * 1000) : 'N/A';
}

export default {
  timestampms,
  timestampmsWithTimezone,
  timestampToDateString,
  setTimezone,
};

export const exportForTesting = {
  getTimeZone,
  formatDate,
};
